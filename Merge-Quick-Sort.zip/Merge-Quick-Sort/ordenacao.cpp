#include <iostream>
#include <vector>
#include <cstdlib>
#include <ctime>
#include <chrono>
#include <algorithm>

using namespace std;

// MERGE SORT
void merge(vector<int>& vetor, int inicio, int meio, int fim) {
    vector<int> auxiliar;
    int i = inicio;
    int j = meio + 1;

    while (i <= meio && j <= fim) {
        if (vetor[i] <= vetor[j]) {
            auxiliar.push_back(vetor[i]);
            i++;
        } else {
            auxiliar.push_back(vetor[j]);
            j++;
        }
    }

    while (i <= meio) {
        auxiliar.push_back(vetor[i]);
        i++;
    }

    while (j <= fim) {
        auxiliar.push_back(vetor[j]);
        j++;
    }

    for (int k = 0; k < static_cast<int>(auxiliar.size()); k++) {
        vetor[inicio + k] = auxiliar[k];
    }
}

void mergeSort(vector<int>& vetor, int inicio, int fim) {
    if (inicio < fim) {
        int meio = inicio + (fim - inicio) / 2;

        mergeSort(vetor, inicio, meio);
        mergeSort(vetor, meio + 1, fim);

        merge(vetor, inicio, meio, fim);
    }
}

// QUICK SORT
int particionar(vector<int>& vetor, int inicio, int fim) {
    int pivo = vetor[fim];
    int i = inicio - 1;

    for (int j = inicio; j < fim; j++) {
        if (vetor[j] <= pivo) {
            i++;
            swap(vetor[i], vetor[j]);
        }
    }

    swap(vetor[i + 1], vetor[fim]);
    return i + 1;
}

void quickSort(vector<int>& vetor, int inicio, int fim) {
    if (inicio < fim) {
        int posicaoPivo = particionar(vetor, inicio, fim);

        quickSort(vetor, inicio, posicaoPivo - 1);
        quickSort(vetor, posicaoPivo + 1, fim);
    }
}

int main() {
    int tamanho;
    int opcao;

    srand(static_cast<unsigned int>(time(nullptr)));

    cout << "=== COMPARACAO DE ALGORITMOS ===\n";
    cout << "Digite o tamanho do array: ";
    cin >> tamanho;

    if (!cin || tamanho <= 0) {
        cout << "Tamanho invalido!\n";
        return 1;
    }

    vector<int> vetor(tamanho);

    for (int i = 0; i < tamanho; i++) {
        vetor[i] = rand() % 10000;
    }

    cout << "\nArray gerado com " << tamanho << " elementos.\n";

    cout << "\nEscolha o algoritmo:\n";
    cout << "1 - Merge Sort\n";
    cout << "2 - Quick Sort\n";
    cout << "Opcao: ";
    cin >> opcao;

    if (!cin || (opcao != 1 && opcao != 2)) {
        cout << "Opcao invalida!\n";
        return 1;
    }

    auto inicio = chrono::high_resolution_clock::now();

    if (opcao == 1) {
        mergeSort(vetor, 0, tamanho - 1);
    } else {
        quickSort(vetor, 0, tamanho - 1);
    }

    auto fim = chrono::high_resolution_clock::now();
    chrono::duration<double, milli> duracao = fim - inicio;

    cout << "\nAlgoritmo utilizado: "
         << (opcao == 1 ? "Merge Sort" : "Quick Sort") << "\n";
    cout << "Tempo de ordenacao: " << duracao.count()
         << " milissegundos\n";

    cout << "\nArray ordenado:\n";
    for (int i = 0; i < tamanho; i++) {
        cout << vetor[i] << " ";
    }
    cout << "\n";

    return 0;
}
