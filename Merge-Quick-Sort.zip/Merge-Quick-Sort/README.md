# Comparação entre Merge Sort e Quick Sort

## Descrição
Programa em C++ desenvolvido para a atividade de Complexidade de Algoritmos e Estrutura de Dados.

O programa:
1. Solicita ao usuário o tamanho do array.
2. Preenche o array com números inteiros aleatórios.
3. Permite escolher entre Merge Sort e Quick Sort.
4. Mede e apresenta o tempo gasto na ordenação.
5. Exibe o array ordenado.

## Arquivos
- `ordenacao.cpp`: código-fonte do programa.

## Como compilar
Com um compilador C++ instalado, execute:

```bash
g++ ordenacao.cpp -o ordenacao
```

## Como executar
No terminal:

```bash
./ordenacao
```

No Windows, dependendo do ambiente:

```bash
ordenacao.exe
```
